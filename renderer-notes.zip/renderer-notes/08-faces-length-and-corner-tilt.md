# Chapter 8 — Length, Normalize, Solid Faces, Standing on a Corner

## Length and normalize (these finish Phase 4)

**Length** of a vector is the straight-line distance from the origin to its
point. In 2D it's the long side of a right triangle: long side² = short² +
other short². For (3, 4): 9 + 16 = 25, so the length is 5. (Check it with a
ruler on a grid.)

In 3D it's the same idea used twice:
1. Across the floor: d² = x² + z²
2. Then up: length² = d² + y² = x² + y² + z²

```cpp
float length(Vec3 a){
    return std::sqrt(a.x*a.x + a.y*a.y + a.z*a.z);
}
```
Tests: length({1,2,2}) = 3, length({3,4,0}) = 5 (z adds nothing).

**Normalize** scales a vector so its length is exactly 1 and keeps its
direction. Divide each part by the vector's own length: dividing by any
number shrinks the arrow without turning it, and dividing by its own length
shrinks it to 1.

```cpp
Vec3 normalize(Vec3 a){
    float len = length(a);
    if (len == 0) return a;          // a zero vector has no direction
    return {a.x / len, a.y / len, a.z / len};
}
```
Tests: normalize({3,4,0}) = (0.6, 0.8, 0). normalize({1,2,2}) =
(0.333, 0.667, 0.667). length(normalize(v)) = 1 (a float may print
0.99999994, which is rounding, not a bug).

Why it matters: the dot product of two vectors of length 1 is exactly the
cosine of the angle between them, which is what lighting needs (Phase 8). The
face normal and the light direction are both normalized first. The zero guard
is real: the cross product of two parallel edges (a degenerate triangle) is
the zero vector.

## The cube and its faces

Corner numbering (as the camera sees the cube at the start; x right, y down,
z into the screen):
```
near face:  0 top-left, 1 top-right, 2 bottom-right, 3 bottom-left   (z = 3.5)
far face:   4 top-left, 5 top-right, 6 bottom-right, 7 bottom-left   (z = 9.5)
```

Face names are **painted on the cube and turn with it**. "Near" means the face
that contains corners 0, 1, 2, 3, not "whichever face is nearest right now".
Which corners belong to which face comes from the coordinates:
```
x = -3: 0, 3, 4, 7      x = +3: 1, 2, 5, 6
y = -3 (top): 0, 1, 4, 5    y = +3 (bottom): 2, 3, 6, 7
z = 3.5: 0..3          z = 9.5: 4..7
```

**A face is two triangles.** After rotation and projection a face is a
general four-sided shape, not a square, so there's no "fill a square"
routine. List the four corners clockwise as seen from **outside** the cube,
call them a, b, c, d, and fill (a,b,c) and (a,c,d). The starting corner is
free: it only chooses which diagonal the face is cut along. The direction is
what matters.

Corners read top-left, top-right, bottom-right, bottom-left from outside:
```
near          {0,1,2,3}
x = +3 face   {1,5,6,2}
far           {5,4,7,6}
x = -3 face   {4,0,3,7}
top           {4,5,1,0}
bottom        {3,2,6,7}
```
(The far face done as {4,6,5} and {4,7,6} is the same face started from a
different corner, and also works.)

**Why the near face is clockwise and the far face looks counter-clockwise.**
The rule is "clockwise from outside". At the start the camera is outside the
near face (it sees it clockwise) but looks at the far face from inside,
through the cube, so the same order looks counter-clockwise. Turn the cube
and when the far face points at the camera, it looks clockwise on screen and
gets drawn. The numbers never change; only the side the camera looks from.

**Which faces get drawn.** `filltriangle` only fills clockwise triangles
(`w + bias > 0` on all three edges). A face turned away from the camera is
counter-clockwise on screen, so it draws nothing. This is back-face culling,
done for free by the winding order. For a convex solid like a cube, the faces
that remain never overlap each other, so no depth test is needed. It stops
working for shapes with dents or for overlapping objects, which is what the
z-buffer in Phase 7 is for.

In the original setup (camera 6.5 from the cube's centre, face 3 from the
centre) the near face turns away at about 62° of spin and a side face appears
at about 27°, so there's always a face on screen.

`visible[i]` does **not** mean "this corner faces the camera". It means "this
corner could be projected" (`w > 0.5`). Facing is decided by the clockwise
test.

```cpp
int faces[6][4] = {
    {0,1,2,3}, {1,5,6,2},
    {5,4,7,6}, {4,0,3,7},
    {4,5,1,0}, {3,2,6,7}
};
int colors[6][4] = {
    {0,0,255,255},   {255,0,255,255},
    {0,255,255,255}, {255,128,0,255},
    {255,0,0,255},   {0,255,0,255}
};

for (int i = 0; i < 6; i++) {
    int v1 = faces[i][0], v2 = faces[i][1], v3 = faces[i][2], v4 = faces[i][3];
    if (visible[v1] && visible[v2] && visible[v3] && visible[v4]) {
        filltriangle(framebuffer, (int)sp[v1].x, (int)sp[v1].y,
                     (int)sp[v2].x, (int)sp[v2].y, (int)sp[v3].x, (int)sp[v3].y,
                     colors[i][0], colors[i][1], colors[i][2], colors[i][3]);
        filltriangle(framebuffer, (int)sp[v1].x, (int)sp[v1].y,
                     (int)sp[v3].x, (int)sp[v3].y, (int)sp[v4].x, (int)sp[v4].y,
                     colors[i][0], colors[i][1], colors[i][2], colors[i][3]);
    }
}
```

Bugs hit:
- The face check used `visible[0]` and `visible[3]` for every face instead of
  the face's own four corners. It only works while every corner projects.
- Red lines showing through a blue face: the 12-edge wireframe was still being
  drawn after the fill. `setpixel` overwrites bytes and never blends, so the
  alpha value does nothing. A wireframe also can't know which edges are hidden.
- A loop variable called `a` hiding the alpha parameter (shadowing).

## The top-left rule, final form (clockwise only)

```cpp
bool istopleft(int ax, int ay, int bx, int by){
    bool istop  = (ay == by) && (bx > ax);   // flat, walking right
    bool isleft = (ay > by);                 // walking up (same as by < ay)
    return istop || isleft;
}
// bias is 1 for a top or left edge, 0 otherwise
bool inside = (w1 + bias1 > 0 && w2 + bias2 > 0 && w3 + bias3 > 0);
```

A pixel exactly on an edge has `w = 0`. `0 + 1 > 0` is true (claimed) and
`0 + 0 > 0` is false (given to the neighbour). The bias changes nothing for
any other pixel.

**Why accepting both windings with a `< 0` branch broke it.** On the negative
side `w + bias < 0` is false for `w = 0` whichever bias you have, so both
triangles reject every on-the-edge pixel and a black crack opens along the
shared diagonal. It only shows at moments when many pixels sit exactly on the
line (slopes like 1:1; a segment between whole-number points has
gcd(dx, dy) + 1 such pixels), which is why it appeared briefly during the
spin. Clockwise-only fixes it. (Accepting both would need `w - bias < 0` on
the negative side, but then back faces draw again.)

"Left" and "right" in the rule name say where the edge sits on the shape. For
a clockwise triangle, the right side is walked downward (`by > ay`) and the
left side upward. A flat edge needs its own clause (`istop`) because `by < ay`
is false for it in both directions.

## Standing on a corner

One tilt leaves the cube on an **edge**. In the front view it looks like a
corner at the bottom of a diamond, but that point is an edge seen end-on,
running toward the camera. Standing on a real corner takes two tilts.

Chain (applied right to left): `toorigin`, `rotateZ(45°)`, `rotateX(35.264°)`,
`rotateY(spin)`, `back`, `view`, `perspective`:
```cpp
mat4 x = pers.multiply(view)
            .multiply(back)
            .multiply(rotateY)
            .multiply(rotateX)
            .multiply(rotateZ)
            .multiply(toorigin);
```
The two tilts stay fixed. Only the spin angle grows. If a tilt keeps changing,
the corner wanders.

**Where 35.264° comes from.** After the first tilt, the cube stands on an edge:
- from the centre straight down to the middle of that edge: half a face
  diagonal = a√2/2 (4.24 for a = 6)
- from the middle of that edge to the corner at its end: half an edge = a/2 (3)

Those two lengths and the line from the centre to the corner make a right
triangle. The second tilt is the angle between "straight down" and that line:
```
tan θ = opposite / adjacent = (a/2) / (a√2/2) = 1 / √2
θ = arctan(1/√2) = 35.264°
```
The cube's size cancels, so the angle is the same for any cube. In code:
```cpp
float tilt = std::atan(1.0f / std::sqrt(2.0f)) * 180.0f / 3.14159265f;
```

**Why not 45° twice.** 45° puts a corner under the centre of a *square*, and
that's what the first tilt does (the front view is a square). The second tilt
tips the *side view*, which is a 6 wide by 8.49 tall rectangle, because
standing on an edge makes the height the face diagonal (6 × 1.414). 45° would
need both legs of the triangle to be equal, and they're 3 and 4.24. At 45° the
corner lands about 0.88 units to one side of the point under the centre (9.7°
off vertical), and the corner circles as the cube spins.

**Check with the matrices.** The space diagonal of the cube is (1, 1, -1).
rotationZ(45°) gives (0, 1.414, -1). rotationX(35.264°) then gives
(0, 1.732, 0), straight up, and 1.732 = √3 is the diagonal's length.

It's a known angle: the angle between a cube's space diagonal and a face
diagonal. Classic isometric views use the same two steps (45°, then 35.264°).

## Field of view, near plane, far plane (not needed yet)

The camera sees a wedge of space (a frustum):
- **Field of view:** the angle of the wedge. Your `f` already sets it. For a
  vertical field of view, `f = (HEIGHT / 2) / tan(fov / 2)`. f = 650 on a
  1080-tall window is about 79°, and a 60° field of view gives
  f = 540 / tan(30°) = 935.
- **Near plane:** the closest distance that gets drawn. `toscreen` rejects
  `w <= 0.5`, which is a rough version. Cutting a triangle exactly at the plane
  is clipping (Phase 10).
- **Far plane:** the farthest distance that gets drawn. You have none, so
  everything is drawn, just small. A software renderer's z-buffer (Phase 7)
  can store depth as it is, so this is optional.
- **Aspect ratio** isn't a gap: x and y use the same scale, so nothing is
  stretched.

## Phase 5 closed

The milestone (a rotating 3D cube with correct perspective) is met, and the
cube is solid. Moved to Phase 10: clipping at the near plane, a camera that
can turn, field of view as an angle, the far plane.
