# Chapter 2 — The Framebuffer

## The core idea

A screen is a grid of colored pixels. A **framebuffer** is an array in your
own program's memory, one entry per pixel, holding that pixel's color.
"Rendering a frame" means: fill this array correctly, then hand the whole
thing to the window library to display at once.

Two reasons to own this array yourself instead of drawing straight to the
screen:
1. You need to **read pixels back** later (e.g. Phase 7's z-buffer — "what's
   already here before I overwrite it").
2. **Atomic updates avoid flicker.** Draw everything into your own private
   array first, then flip the whole finished array to the screen in one
   shot — this is why nothing appears half-drawn mid-frame.

## Why memory is always 1D

RAM is fundamentally one long strip of bytes, each with a single address.
There is no true "2D memory" at the hardware level. So a 2D image always
ends up flattened into one line somehow — the only question is whether you
flatten it explicitly yourself, or let a nested container (`vector<vector<>>`)
fake 2D-ness for you with hidden pointer indirection (slower — rows aren't
guaranteed to sit next to each other in memory, so the CPU has to chase
pointers instead of doing direct arithmetic).

We use one flat array:
```cpp
const int WIDTH = 800;
const int HEIGHT = 600;
std::vector<uint8_t> framebuffer(WIDTH * HEIGHT * 4);
```
`uint8_t` is just a small integer type, 0–255, one byte — exactly enough
range for one color channel. `WIDTH * HEIGHT * 4` = one slot per pixel
per channel (R, G, B, A).

## The indexing formula

To find where pixel `(x, y)`, channel `z` (0=R, 1=G, 2=B, 3=A) lives in the
flat array:
```
index = (y * width + x) * 4 + z
```
Built up piece by piece:
- `y * width` — skip past every full row above row `y`.
- `+ x` — move across to the correct column within that row.
- At this point, `(y * width + x)` is "which pixel number is this" in
  reading order (0, 1, 2, 3, ...).
- `* 4` — each pixel occupies 4 consecutive byte slots, so convert
  "pixel number" into "starting byte position."
- `+ z` — pick which of the 4 slots (R/G/B/A) you actually want.

Small worked example, width = 3, pixel (x=2, y=1), channel z=1 (Green):
```
index = (1*3 + 2)*4 + 1 = (5)*4 + 1 = 21
```

## setPixel

```cpp
void setpixel(std::vector<uint8_t>& framebuffer, int x, int y,
              uint8_t r, uint8_t g, uint8_t b, uint8_t a) {
    int index = (y * WIDTH + x) * 4;
    framebuffer[index + 0] = r;
    framebuffer[index + 1] = g;
    framebuffer[index + 2] = b;
    framebuffer[index + 3] = a;
}
```
`std::vector<uint8_t>& framebuffer` — passed **by reference** (`&`), not by
value. A copy would mean the function scribbles on a disposable duplicate
that vanishes when the function ends — the real framebuffer outside would
never change. Reference means "operate on the actual original."

This function only **writes** a color in — it does not read one back. A
separate read-style function would be needed for that (used later, e.g. for
depth testing).

## Getting the array onto the actual screen

The framebuffer is just a plain C++ array — the window library has no idea
it exists until you hand it over, every frame:
```cpp
sf::Texture texture;
texture.create(WIDTH, HEIGHT);
// each frame:
texture.update(framebuffer.data());
window.clear();
window.draw(sprite);   // sprite bound to texture via sprite.setTexture(texture)
window.display();
```
`texture.update()` must happen every frame if the framebuffer's contents can
change between frames — not just once before the loop, or animation
wouldn't show. Clearing the framebuffer each frame (`std::fill(framebuffer
.begin(), framebuffer.end(), 0)`) becomes necessary once anything moves or
changes — otherwise old pixels from previous frames never get erased.

## Milestone for this chapter

A manually-set pixel (or line of pixels) visibly rendering on screen through
the real framebuffer → texture → sprite pipeline.
