# Chapter 6 — Perspective Projection (Minimal Version)

## Screen coordinate convention — recap, load-bearing for everything below

x=0 at left, increasing rightward. **y=0 at top, increasing downward** —
opposite of school-math coordinates. Consequence: if A has smaller y than
B, A is *higher up* on screen, not "less" in any everyday sense.
`P.y - A.y` is negative when P is above A, positive when below — feels
backwards at first, it's just the convention.

This project chose: **positive y in 3D world space also means down**,
matching the screen exactly. This means no negation is needed anywhere in
the projection formula — but it does mean cube vertices meant to be
visually "top" must be given **negative** y when defining them by hand.
(The opposite convention — positive y = up in 3D, matching school math — is
equally valid, but then the projection formula needs an explicit `-y` to
compensate. Pick one convention and stay consistent; mixing them silently
produces an upside-down render.)

## The perspective divide

The one thing that makes distant objects look smaller: divide x and y by z
(depth).
```
screenX = (x / z) * scale + centerX
screenY = (y / z) * scale + centerY
```
- Small z (close) → dividing by a small number → bigger result → object
  appears larger/more spread from center.
- Large z (far) → dividing by a big number → smaller result → shrinks
  toward center.
- `scale` — tuning constant controlling how dramatic the effect looks
  (no single "correct" value; picked by eye, e.g. 200).
- `centerX`/`centerY` — shift so `(0,0,z)` lands at screen center instead
  of the top-left corner (`screenWidth/2`, `screenHeight/2`).

Worked example: `Vec3{2,1,5}`, scale=200, center=(400,300):
```
screenX = (2/5)*200 + 400 = 480
screenY = (1/5)*200 + 300 = 380
```
Moving the same point closer (z=2 instead of 5) increases the spread from
center — confirms the "closer = more spread out" behavior by hand, before
trusting the code.

## Implementation

```cpp
struct Vec3 {
    float x, y, z;
    // ... operators ...

    Vec2 screenpoint(int screenwidth, int screenheight) {
        float scale = 200.0f;
        float CenterX = screenwidth / 2.0f;
        float CenterY = screenheight / 2.0f;

        Vec2 result;
        result.x = ((x/z) * scale) + CenterX;
        result.y = ((y/z) * scale) + CenterY;
        return result;
    }
};
```
Lives as a method on `Vec3` (could equally be a free function, or a
`static` method inside `Vec2` — three structurally different but
functionally identical choices; this project settled on the `Vec3` method
version). Returns `Vec2`, not `Vec3` — projection is specifically "collapse
3D down to 2D," so the z is deliberately discarded in the return value.

## Full pipeline: real 3D points → drawn cube

```cpp
Vec3 cubeVerts[8] = {
    {-1,-1,5}, {1,-1,5}, {1,1,5}, {-1,1,5},   // front face, z=5
    {-1,-1,8}, {1,-1,8}, {1,1,8}, {-1,1,8}    // back face,  z=8 (farther)
};

void drawcube(std::vector<uint8_t>& framebuffer, Vec3 vert[8],
              uint8_t r, uint8_t g, uint8_t b, uint8_t a) {

    Vec2 p[8];
    for (int i = 0; i < 8; i++)
        p[i] = vert[i].screenpoint(WIDTH, HEIGHT);

    int edges[12][2] = {
        {0,1},{1,2},{2,3},{3,0},   // front face
        {4,5},{5,6},{6,7},{7,4},   // back face
        {0,4},{1,5},{2,6},{3,7}    // connecting edges
    };

    for (int i = 0; i < 12; i++) {
        int idxA = edges[i][0];
        int idxB = edges[i][1];
        drawline(framebuffer, (int)p[idxA].x, (int)p[idxA].y,
                               (int)p[idxB].x, (int)p[idxB].y, r,g,b,a);
    }
}
```
`p[8]` is a **lookup table**: project all 8 corners once, up front, then
every edge just looks up the already-computed screen position by index
instead of recomputing it — several vertices are shared by 3 edges each, so
recomputing per-edge would waste work.

The `edges` array's indices are meaningless without a `verts` array defined
in the exact order `edges` assumes (front face 0-3 in order around the
square, back face 4-7 in matching relative order, then straight 0↔4 etc.
connections). This is an implicit, fragile contract between the two arrays
— reordering one without the other silently produces a tangled wireframe,
no crash, no error.

## Real bugs hit and fixed while building this

- `(0,1)` instead of `{0,1}` in the edges array — parentheses invoke the
  **comma operator** (evaluates 0, discards it, evaluates to just 1), not
  "a pair of numbers." Compiles fine, silently produces garbage.
- A loop variable named `a` for a vertex index, inside a function that
  already has a parameter named `a` (alpha color) — **shadowing**: the
  inner `a` hides the outer one for the rest of the loop, so `drawline(...,
  a)` silently passes a vertex index where alpha was expected. No compiler
  error; wrong colors instead.
- `drawcube(framebuffer, cubeVerts[8], ...)` — `cubeVerts[8]` is a single
  out-of-bounds element access (valid indices are 0–7 for an 8-element
  array), not "the whole array." Needed to be `drawcube(framebuffer,
  cubeVerts, ...)` — pass the array itself, no index.

## Known limitations of this minimal version (not yet solved, on purpose)

- No near-plane clipping — points very close to or behind the camera
  (z near 0 or negative) will misbehave (division by near-zero or negative
  z breaks the "smaller = farther" assumption).
- Jagged/staircase edges, especially visible on very shallow or steep
  lines — inherent to any pixel-grid rasterizer, not a bug. Fixable later
  via anti-aliasing (coverage blending or supersampling); explicitly not a
  current priority.
- This is **not** using a real matrix yet — only one hardcoded operation
  (perspective divide). Rotating or moving the cube would currently require
  manually recomputing every vertex's x/y/z by hand. `Mat4` (next chapter,
  not yet written) exists specifically to bundle translation + rotation +
  scale + projection into one uniform, reusable operation per point.

## Milestone for this chapter

A cube defined with genuine 3D coordinates (not hand-picked screen
positions) rendering with correct perspective — back face visibly smaller
than the front face, confirming the divide is doing real work.
