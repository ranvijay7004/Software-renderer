# Chapter 1 — Environment & Toolchain

## Why a build system at all

A compiler (g++) turns `.cpp` files into machine code. For one file, you
could just run `g++ main.cpp -o main`. The moment you add an external
library, or split code across files, doing this by hand becomes
unmanageable — you'd need to remember every include path, every library to
link, on every machine.

**CMake** doesn't compile anything itself. It's a *generator*: you describe
your project in `CMakeLists.txt`, and CMake produces the actual
platform-specific build files (Ninja files on this setup), which then get
compiled. Same `CMakeLists.txt` works on Linux, Windows, Mac.

## Anatomy of a CMakeLists.txt

```cmake
cmake_minimum_required(VERSION 3.20)
project(SoftwareRenderer LANGUAGES CXX)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)

add_executable(renderer src/main.cpp)

target_include_directories(renderer PRIVATE <path>/include)
target_link_directories(renderer PRIVATE <path>/lib)
target_link_libraries(renderer PRIVATE SDL2)
```

- `cmake_minimum_required` — floor version, fails loudly if too old rather
  than breaking mysteriously later.
- `project(... LANGUAGES CXX)` — names the project, declares C++ as the
  language.
- `CMAKE_CXX_STANDARD 17` — pins the language standard so behavior doesn't
  silently vary by compiler default.
- `add_executable` — declares the actual output: an exe named `renderer`,
  built from the listed source files.
- `target_include_directories` — where the *compiler* looks for headers.
- `target_link_directories` — where the *linker* looks for library files.
- `target_link_libraries` — which compiled library code to actually link in.

`find_package(SDL2 CONFIG REQUIRED)` is the vcpkg-style alternative to
manual include/link directories — it auto-discovers all of this *if* the
library ships the right config files. `REQUIRED` makes it fail fast, at the
exact missing piece, instead of failing later with a confusing linker error
about an unresolved target.

## The SDL2/MinGW saga — what actually went wrong, and why

This took most of a full day, and every failure was a real, well-known issue
— not something done wrong through inexperience.

### Problem 1: ABI mismatch (MSVC vs MinGW)

Different compilers (MSVC vs g++/MinGW) don't produce binary-compatible
code on Windows — different name mangling, different stack-checking hooks,
different runtime conventions. This is called an **ABI mismatch**.

vcpkg's default triplet (`x64-windows`) builds libraries assuming **MSVC**.
Compiling with **g++** and linking against an MSVC-built SDL2 produced:
```
undefined reference to `_RTC_CheckStackVars'
undefined reference to `_RTC_InitBase'
```
These are MSVC-specific debug hooks g++'s linker has never heard of.

**Fix that actually worked**: stop using vcpkg's SDL2 for MinGW entirely.
Download SDL2's officially prebuilt MinGW package directly from SDL's own
GitHub releases (`SDL2-devel-X.X.X-mingw.zip`) — built with the matching
ABI from the start.

### Problem 2: SDL wants to own `main`

On Windows, `SDL.h` normally macro-renames your `main` to `SDL_main`,
expecting `SDL2main.lib` to provide the real entry point that calls yours.
If you don't link `SDL2main`, the linker complains:
```
undefined reference to `SDL_main'
```

**Fix**: opt out of that renaming entirely.
```cpp
#define SDL_MAIN_HANDLED
#include <SDL.h>
// ...
int main() {
    SDL_SetMainReady();
    // normal code
}
```
Then don't link `SDL2main` at all. This is a standard, common pattern, not a
hack.

### Problem 3: missing runtime DLLs at launch

Build succeeds, but running the exe fails with something like:
```
error while loading shared libraries: api-ms-win-crt-string-l1-1-0.dll
```
This is a **runtime** (not build-time) problem: the linker only checks that
needed functions exist somewhere; Windows' loader is what actually finds
the DLLs, right before the program runs, and fails if one's missing.

**Fix**: statically link GCC's own runtime instead of depending on external
DLLs for it:
```cmake
target_link_options(renderer PRIVATE -static-libgcc -static-libstdc++ -static-libpthread)
```
SDL2 itself still ships as a separate DLL — copy `SDL2.dll` next to the
built exe.

## Eventual switch: SDL2 → SFML 2.6.2

After Phase 0/1, switched windowing libraries entirely — a deliberate,
reasoned choice, not a failure. Both SDL2 and SFML are capable of "give me a
raw pixel buffer, I'll draw into it myself" — the actual requirement for a
software renderer, since none of the library's own drawing functions get
used either way. SFML 2.6.2 specifically (not 3.0) was kept to preserve
prior familiarity with its API, since the windowing layer is infrastructure,
not the deliverable — the portfolio value is entirely in the renderer code
itself.

## Milestone for this chapter

A blank SFML window opens, centered, resizable, and closes cleanly on
Escape or the close button, with no hang and no leaked process.
