# Software Renderer — Revision Notes

A textbook-style reference for everything covered so far. Read a chapter,
close it, try to write that piece of the renderer from scratch, then check
yourself against it.

## Chapters

1. [Environment & toolchain](01-environment-toolchain.md) — CMake, SDL2→SFML,
   MinGW/ABI issues, why each piece exists
2. [The framebuffer](02-framebuffer.md) — memory layout, the indexing formula,
   setPixel
3. [Bresenham's line algorithm](03-bresenham.md) — error accumulation, all 8
   octants, full derivation
4. [Triangle rasterization](04-triangle-rasterization.md) — the edge function,
   bounding boxes, the top-left rule
5. [Vectors — Vec2/Vec3, dot & cross product](05-vectors.md) — operators,
   const-correctness, what dot/cross actually mean
6. [Perspective projection](06-projection.md) — the perspective divide,
   screen coordinate conventions, the first real 3D cube
7. [Matrices](07-matrices.md) — Mat4, rotations, matrix × matrix, the
   perspective matrix, the view matrix
8. [Length, normalize, solid faces, standing on a corner](08-faces-length-and-corner-tilt.md)
   — Vec3 length and normalize, the faces array and winding, the final
   top-left rule, the 35.264° tilt, field of view and near/far planes

Note: chapter 6 describes `Vec3::screenpoint`, which was replaced by the
perspective matrix and `toscreen` in chapter 7.

Read in order — each chapter assumes the previous ones. Code blocks are the
actual, working, debugged code from the project, not simplified textbook
pseudocode.
