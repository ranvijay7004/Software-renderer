# Chapter 5 — Vectors: Vec2, Vec3, Dot & Cross Product

## What Vec2/Vec3 actually are

Just a named bundle of plain numbers — no more magical than `Pixel` bundling
4 `uint8_t`s. `float` is used (not `int`) because 3D math needs decimal
precision (a rotation rarely lands on a clean whole number).

```cpp
struct Vec2 { float x, y; };
struct Vec3 { float x, y, z; };
```

The same struct represents two different *meanings*, decided entirely by
context:
- **A point** — a location in space.
- **A direction/displacement** — an arrow with length, usually obtained as
  the *difference* between two points (`B - A`), not a raw location.

Operations like dot/cross only make geometric sense on directions, not on
two arbitrary unrelated points.

## Operator overloading

C++ doesn't know what `+` means for a custom struct until you teach it, per
type — `sf::Vector2i` supporting `+` is SFML's own code doing this, not a
default behavior every struct gets for free.

```cpp
struct Vec2 {
    float x, y;

    Vec2 operator+(const Vec2& other) const {
        Vec2 result;
        result.x = x + other.x;
        result.y = y + other.y;
        return result;
    }
    Vec2 operator-(const Vec2& other) const {
        Vec2 result;
        result.x = x - other.x;
        result.y = y - other.y;
        return result;
    }
    Vec2 operator*(float scalar) const {
        Vec2 result;
        result.x = x * scalar;
        result.y = y * scalar;
        return result;
    }
};
```
- `const Vec2& other` — `other` is the right-hand operand. `const` here
  protects the *caller's original data* from being modified through the
  reference (a reference is a direct alias, not a copy — changes would
  actually reach back to the caller).
- Trailing `const` (after the parameter list) — promises not to modify the
  object the function was called *on* (the left-hand operand).
- `const` on a plain-value parameter (`float scalar`) protects nothing
  meaningful — the parameter is already a private copy the moment the
  function is called; nothing done to it can reach back to the caller.
  Valid to write, just not functionally necessary the way it is for
  references.

`Vec3` follows the identical pattern with a `z` added everywhere.

## Dot product

```cpp
float dot(const Vec2& a, const Vec2& b) {
    return a.x*b.x + a.y*b.y;
}
// Vec3 version adds + a.z*b.z
```
Produces a single plain number, not a vector. Chosen as a free function
(not a method) here — `dot(a,b)` reads as "compute this named operation,"
rather than "naturally combine two things" the way `+` does; that's the
actual justification for the style split, not just preference.

**What the number means** — verified with real numbers, not just asserted:
- `dot((1,0),(0,1)) = 0` — perpendicular gives exactly zero.
- `dot((1,2),(2,-1)) = 2 + (-2) = 0` — perpendicular gives zero even with
  no individual zero components; the two products cancel by being exact
  opposites. Confirms it's a real geometric fact, not a numeric coincidence.
- `dot((3,0),(5,0)) = 15` — same direction, large positive.
- `dot((3,0),(-5,0)) = -15` — opposite direction, negative.
- `dot((1,0),(1,1)) = 1` — partially aligned (45°), smaller positive.

General rule: `dot(a,b) = |a||b|cos(angle between them)`. Sign and
magnitude track alignment continuously — positive/negative/zero are
milestones on a spectrum, not three disconnected cases.

## Cross product (Vec3 only — no meaningful 2D equivalent)

```cpp
Vec3 cross(const Vec3& a, const Vec3& b) {
    Vec3 result;
    result.x = a.y*b.z - a.z*b.y;
    result.y = a.z*b.x - a.x*b.z;
    result.z = a.x*b.y - a.y*b.x;
    return result;
}
```
Produces a **new vector**, not a number. Its direction is perpendicular to
*both* inputs simultaneously — imagine `a` and `b` both lying flat on one
shared plane; `a×b` stands straight up out of that entire plane, not just
perpendicular to one of the two vectors checked separately.

Verify: `cross((1,0,0), (0,1,0)) = (0,0,1)`. Confirm perpendicularity to
both using dot product (a tool already trusted): `dot((0,0,1),(1,0,0)) = 0`
and `dot((0,0,1),(0,1,0)) = 0`. Both check out.

**What the magnitude means**: `|a×b|` equals the area of the parallelogram
formed by `a` and `b` placed tail-to-tail. This is why the magnitude
depends on the angle between `a` and `b`:
- 0° or 180° apart (same line) — magnitude is exactly 0. Makes sense: no
  single "the" perpendicular direction exists for two vectors lying on one
  line — infinitely many directions would qualify, so the result is
  correctly undefined/zero.
- 90° apart — magnitude is at its largest (biggest possible parallelogram
  for given vector lengths).
- In between — magnitude scales smoothly between those extremes.

Dot and cross track *opposite* things about the same pair of vectors: dot
peaks when vectors are aligned and hits zero at 90°; cross's magnitude is
zero when aligned and peaks at 90°. Complementary, not redundant.

## Where these get used later (why bother at all)

- **Cross product** → a triangle's face normal, via crossing two of its
  edges. Needed for lighting (Phase 8: how much a face points toward a
  light) and back-face culling (Phase 10: skip triangles facing away from
  the camera).
- **Dot product** → measuring alignment between a surface normal and a
  light direction (brighter when facing the light, dark when facing away) —
  same "aligned = positive, perpendicular = zero, opposite = negative"
  idea, applied to lighting instead of abstract angles.

These honestly don't fully click until watched solving a real problem —
expect this chapter to make more sense in hindsight once Phase 5/8 use them
for real, not purely from reading this now.

## Vec4 — deliberately incomplete here

```cpp
struct Vec4 { float x, y, z, w; };
```
Same struct pattern, one more slot. `w` is **not** a spatial direction like
x/y/z — it exists for "homogeneous coordinates," which make perspective
projection work cleanly through matrix multiplication (Phase 5/Mat4). Its
actual meaning is intentionally deferred until Mat4 gives it context;
treating it as "just another axis" right now would be actively wrong.
