# Chapter 4 — Triangle Rasterization

## The problem

Given 3 points forming a triangle, decide which pixels are inside it. Unlike
a line (a path), a triangle is a closed *region* — need an inside/outside
test, not a tracing algorithm.

## The edge function

For one edge from point A to point B, and any test point P:
```
edge(A,B,P) = (B.x-A.x)*(P.y-A.y) - (B.y-A.y)*(P.x-A.x)
```

### Where this actually comes from

The line's slope: `slope = (B.y-A.y)/(B.x-A.x)`.

The line's height at any x-position: `A.y + slope*(P.x - A.x)` — start at
A's height, add however much the line rises walking from A's x over to P's
x. (`(P.x-A.x)` = steps taken; `slope * steps` = total rise; `A.y + rise` =
actual height.)

To check which side P is on, compare P's actual height to the line's height
at that same x-column:
```
P.y - [A.y + slope*(P.x-A.x)]  =  P.y - A.y - slope*(P.x-A.x)
```
Multiply the whole thing by `(B.x-A.x)` (a positive number, so it doesn't
flip the sign) to cancel the division inside `slope`:
```
(B.x-A.x)*(P.y-A.y) - (B.y-A.y)*(P.x-A.x)
```
That's the edge function. It is not a separate mysterious formula — it's
exactly "compare P's height to the line's height at P's column," rewritten
to avoid ever dividing.

### What the sign means

Not "above/below" in general (that only works for horizontal lines) — the
real meaning is "which side of the direction you'd be walking, going from A
toward B" (left of your walking direction vs right of it). This
generalizes to edges at any angle uniformly, which is why one formula
handles all three edges of a triangle regardless of each edge's own angle.

## Inside test: same sign on all three edges

A point is inside a triangle exactly when it's on the **same consistent
side** of all three edges — checked by walking the edges in a **fixed
rotational order** (always A→B, B→C, C→A — consistently clockwise, never
mixed). This is not "alternating" between edges; consistent winding means
an interior point agrees in sign with every edge, because "same side of my
walking direction" rotates naturally with each edge's own direction.

```cpp
int edgeFunction(int ax, int ay, int bx, int by, int px, int py) {
    return (bx - ax) * (py - ay) - (by - ay) * (px - ax);
}
```

## Bounding box optimization

Testing every pixel on the whole screen per triangle is wasteful. Compute
the smallest rectangle containing the triangle first:
```cpp
int minX = std::min({x0, x1, x2});
int maxX = std::max({x0, x1, x2});
int minY = std::min({y0, y1, y2});
int maxY = std::max({y0, y1, y2});
```
`{...}` here is an initializer list — lets `std::min`/`std::max` compare
more than 2 values at once. Only pixels inside this rectangle get tested.

## The top-left rule

Two triangles sharing an edge, each testing `w >= 0` independently, would
**both** draw the shared boundary pixels (double-draw) if both are
inclusive, or **neither** would (a gap) if both are exclusive. Need exactly
one of them to claim each shared pixel.

Classify each edge:
```cpp
bool isTopLeft(int ax, int ay, int bx, int by) {
    bool isTop  = (ay == by) && (bx > ax);   // horizontal, going rightward
    bool isLeft = (by < ay);                  // going upward (screen coords: smaller y = up)
    return isTop || isLeft;
}
```
Top-or-left edges stay inclusive (`>=0`); everything else becomes exclusive
via a bias of -1 (`w - 1 >= 0` means `w` must be strictly > 0):
```cpp
int bias0 = isTopLeft(x0,y0,x1,y1) ? 0 : -1;
bool inside = (w0+bias0 >= 0) && (w1+bias1 >= 0) && (w2+bias2 >= 0);
```
The bias only ever changes the outcome exactly at `w == 0` (precisely the
shared-boundary pixels) — everywhere else, adding -1 to a clearly
positive or clearly negative number changes nothing about the >=0 test.

**Why it actually works for adjacent triangles**: two triangles sharing an
edge, both wound the same consistent rotational direction (e.g. both
clockwise), necessarily walk that *shared physical edge* in **opposite**
directions relative to each other (one sees it as A→B, the other as B→A on
the same line). `isTop`/`isLeft` depend on the direction of travel, so the
classification comes out opposite for the two triangles — exactly one ever
claims the boundary. This guarantee **requires** consistent winding;
mixing clockwise and counter-clockwise triangles breaks it.

This also means the "either all >=0 or all <=0" flexibility (to handle
either winding direction) has to be dropped once using the bias — the bias
version commits to one winding convention throughout.

## Full working code

```cpp
int edgefunction(int ax, int ay, int bx, int by, int px, int py) {
    return (bx-ax)*(py-ay) - (by-ay)*(px-ax);
}

bool isTopLeft(int ax, int ay, int bx, int by) {
    bool istop = (ay == by) && (bx > ax);
    bool isleft = (by < ay);
    return istop || isleft;
}

// vertices must be consistently wound (e.g. clockwise) or the top-left bias breaks
void filltriangle(std::vector<uint8_t>& framebuffer, int x1,int y1,int x2,int y2,
                   int x3,int y3, uint8_t r, uint8_t g, uint8_t b, uint8_t a) {

    int xmin = std::min({x1,x2,x3}), xmax = std::max({x1,x2,x3});
    int ymin = std::min({y1,y2,y3}), ymax = std::max({y1,y2,y3});

    for (int x = xmin; x <= xmax; x++) {
        for (int y = ymin; y <= ymax; y++) {
            int w0 = edgefunction(x1,y1,x2,y2,x,y);
            int w1 = edgefunction(x2,y2,x3,y3,x,y);
            int w2 = edgefunction(x3,y3,x1,y1,x,y);

            int bias0 = isTopLeft(x1,y1,x2,y2) ? 0 : -1;
            int bias1 = isTopLeft(x2,y2,x3,y3) ? 0 : -1;
            int bias2 = isTopLeft(x3,y3,x1,y1) ? 0 : -1;

            bool inside = (w0+bias0>=0) && (w1+bias1>=0) && (w2+bias2>=0);
            if (inside) setpixel(framebuffer, x, y, r,g,b,a);
        }
    }
}
```

## Milestone for this chapter

A solid-filled triangle. Two triangles sharing an edge (e.g. forming a
rectangle) with no gap and no double-draw along the seam — verified visually
(a macro photo of the actual screen is a genuinely good way to check this).
