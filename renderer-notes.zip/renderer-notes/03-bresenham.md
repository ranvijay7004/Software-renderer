# Chapter 3 — Bresenham's Line Algorithm

## The problem

Pixels sit on a grid of whole numbers. A mathematically perfect line
between two points almost never passes through whole-number positions the
whole way — e.g. from (0,0) to (10,4), at x=1 the true line is at y=0.4.
We're forced to approximate with a staircase of whole pixels.

A naive approach recomputes a decimal `y = x * (dy/dx)` at every step and
rounds — correct, but uses floating point and division on every single
pixel, which is slow at scale. Bresenham (1962) gets the identical result
using only integer addition, subtraction, and comparison.

## The core mechanism: tracking drift with an integer error

For a line moving more in x than y (shallow), step `x` by exactly 1 every
time — the only real decision per step is whether `y` also moves.

Track a running **error** — how far the true (decimal) line has drifted
from the current row, measured in integer terms:

```
error starts at 0
each step: error += dy
if error >= dx:
    y steps by 1
    error -= dx
```

Worked example, line (0,0)→(4,2), so dx=4, dy=2:

| step (x→x+1) | error before | +dy | total | ≥dx? | y for next x |
|---|---|---|---|---|---|
| 0→1 | 0 | +2 | 2 | no | y stays 0 |
| 1→2 | 2 | +2 | 4 | yes → reset 0 | y→1 |
| 2→3 | 0 | +2 | 2 | no | y stays 1 |
| 3→4 | 2 | +2 | 4 | yes → reset 0 | y→2 |

Resulting y sequence: 0,0,1,1,2 — matches hand-drawing the staircase.

**Why this works**: the running total *is* `x * dy` (built by repeated
addition instead of one multiplication). `error >= dx` is a stand-in for
"has the true decimal y crossed the next whole number" — checked via
comparison instead of division. `error` is literally the gap between the
ideal continuous line and the discrete pixel row we're actually drawing on
— hence the name.

## Handling any direction (not just rightward/downward)

Compute signed step values once, from comparing start/end points:
```cpp
int cx = (x1 > x0) ? +1 : -1;
int cy = (y1 > y0) ? +1 : -1;
```
Use `x += cx` / `y += cy` instead of hardcoded `+1`. Loop by a **fixed
count** (0 to dx), not by comparing `x <= x1` — that comparison silently
breaks depending on which direction you're going (if x1 < x0, `x <= x1` is
false from the very first check).

## Handling steep lines (y changes faster than x)

Everything above assumes `dx >= dy`. For a steep line, **swap the roles of
x and y** before running the identical logic, then swap back only when
actually setting the pixel:
```cpp
bool steep = std::abs(y1 - y0) > std::abs(x1 - x0);
if (steep) { std::swap(x0, y0); std::swap(x1, y1); }
// ... dx, dy, cx, cy, error, loop — all computed AFTER the swap, unchanged otherwise
if (steep) setpixel(framebuffer, y, x, r,g,b,a);   // swapped back
else       setpixel(framebuffer, x, y, r,g,b,a);
```
This is the elegant part: one piece of logic, written once, handles all 8
octants (shallow/steep × 4 direction combinations) via swapping + signed
steps, rather than 8 separate code paths.

## Full working code

```cpp
void drawline(std::vector<uint8_t>& framebuffer, int x0, int y0, int x1, int y1,
              uint8_t r, uint8_t g, uint8_t b, uint8_t a) {

    bool steep = std::abs(y1 - y0) > std::abs(x1 - x0);
    if (steep) {
        std::swap(x0, y0);
        std::swap(x1, y1);
    }

    int dx = std::abs(x1 - x0);
    int dy = std::abs(y1 - y0);
    int cx = (x1 > x0) ? +1 : -1;
    int cy = (y1 > y0) ? +1 : -1;

    int x = x0;
    int y = y0;
    int error = 0;

    for (int i = 0; i <= dx; i++) {
        if (steep) setpixel(framebuffer, y, x, r, g, b, a);
        else       setpixel(framebuffer, x, y, r, g, b, a);

        error += dy;
        if (error >= dx) {
            y += cy;
            error -= dx;
        }
        x += cx;
    }
}
```

## Real bugs hit and fixed while building this (worth recognizing the shapes of)

- Looping with `for (x = x0; x <= x1; x += cx)` — breaks the instant the
  line goes leftward, since the condition is false on the very first check.
  Fixed by looping a fixed count instead.
- Declaring `x` once before the loop but then updating a *different*
  variable (`x0 += cx`) inside it — `x` itself never moves, `setpixel`
  silently draws the same column forever.
- `error += dx` instead of `error += dy` — a one-letter typo that still
  compiles and still "mostly" draws something, since both are just `int`s.
- Forgetting to actually use `cx`/`cy` inside the loop after computing
  them (`x++`/`y++` left over from an earlier draft) — direction-handling
  code that exists but never runs.

None of these threw compiler errors — they're all logically valid C++, just
not doing what was intended. The only way to catch them is tracing through
by hand with real numbers.

## Milestone for this chapter

Lines at any angle, any direction, rendering with no gaps — verified with at
least one clearly diagonal and one clearly shallow test line.
