# Chapter 7 — Matrices: Mat4, Rotation, Combining, Perspective, View

## Why matrices

Moving, resizing, rotating and projecting a point are four different kinds of
calculation. A matrix lets them all be the same single operation:
"multiply this point by this matrix". Which transformation happens depends
only on **which numbers sit inside the matrix**. The multiplying code never
changes.

## What a Mat4 is

16 plain numbers in a 4×4 grid, stored here as four `Vec4` rows. The "16" is
just how many numbers the grid holds, nothing to do with how many operations
exist.

```cpp
struct mat4 {
    Vec4 row0, row1, row2, row3;
};
```

## Points as towers (the thing that makes everything else click)

A point is a **column** (a 4×1 "tower"), not a row of numbers:

```
| 1 0 0 5 |   | 2 |
| 0 1 0 0 | × | 3 |
| 0 0 1 0 |   | 4 |
| 0 0 0 1 |   | 1 |
```

So matrix × point is "each row of the matrix against the tower". Matrix ×
matrix is the same thing repeated: a matrix is just several towers side by
side. This was always row × column; it just wasn't drawn that way.

## Vec3 → Vec4 → Vec3

Your objects are `Vec3`. Matrices have 4 columns, so a `Vec3` point gets a
temporary fourth number, `w = 1`: `Vec4 p = {x, y, z, 1};`. `Vec4` is
scaffolding for the multiply, not a second way of storing objects.

## Matrix × point

Each output coordinate is one row dotted with the point:

```cpp
Vec4 multiply(Vec4 a) const {
    Vec4 result;
    result.x = dot(row0, a);
    result.y = dot(row1, a);
    result.z = dot(row2, a);
    result.w = dot(row3, a);
    return result;
}
```

`dot(Vec4, Vec4)` returns a plain `float` (inputs being `Vec4` doesn't make
the output a `Vec4`).

Here dot is just "multiply matching numbers and add" arithmetic. The matrix's
contents decide what the result means (a shift, a spin, a resize). It has
nothing to do with angles or lighting in this use.

## Two views of the same multiply

- **By rows**: row `i` makes output `i`, as a mix of all four inputs.
- **By columns**: input `j` multiplies column `j`, and you add the scaled
  columns. For `p = (2,3,4,1)` and a translation by (5,0,0):
  `2*col0 + 3*col1 + 4*col2 + 1*col3 = (2,0,0,0)+(0,3,0,0)+(0,0,4,0)+(5,0,0,1) = (7,3,4,1)`

Column 3 is the one multiplied by `w` (always 1 for a point), so it's added in
full every time. That's why a translation's offsets sit in column 3.

## The three basic transforms

```cpp
static mat4 translation(float dx, float dy, float dz) {
    mat4 result;
    result.row0 = {1,0,0,dx};
    result.row1 = {0,1,0,dy};
    result.row2 = {0,0,1,dz};
    result.row3 = {0,0,0,1};
    return result;
}

static mat4 scaler(float sx, float sy, float sz) {
    mat4 result;
    result.row0 = {sx,0,0,0};
    result.row1 = {0,sy,0,0};
    result.row2 = {0,0,sz,0};
    result.row3 = {0,0,0,1};
    return result;
}
```

- Translation **adds** a constant (the offset multiplies `w = 1`).
- Scale **multiplies** each coordinate separately.
- Verified by hand: translation(5,0,0) on (10,3,2) gives (15,3,2).

A static builder is called as `mat4::translation(5,0,0)` (needs the `mat4::`
prefix, but no existing matrix).

## Rotation

Rotation is different from the other two: it **mixes two coordinates**.
Derivation (distance and angle):

- A point is `x = r·cos(φ)`, `y = r·sin(φ)` for some distance `r` and angle `φ`.
- Rotating by `θ` keeps `r` the same (that's what rotation means: a clock hand
  doesn't change length) and adds `θ` to the angle.
- `x' = r·cos(φ+θ)`, and the angle-addition identity gives
  `x' = r·cos(φ)cos(θ) − r·sin(φ)sin(θ)`.
- `r·cos(φ)` **is** `x` and `r·sin(φ)` **is** `y`, so
  `x' = x·cos(θ) − y·sin(θ)` and `y' = x·sin(θ) + y·cos(θ)`.
- `r` cancels out of the final formula. You never compute it.

Every rotation preserves each point's distance from the center of rotation.

**Radians, not degrees.** `cos` and `sin` take radians:
`radians = degrees * (3.14159265f / 180.0f)`. Passing raw degrees means 1
degree is treated as 1 radian (about 57°), which makes the spin far too fast.

**Building each matrix: columns are inputs.** Column 0 multiplies x, column 1
multiplies y, column 2 multiplies z. Write the formula for each output, then
place the numbers in the columns of the inputs they multiply.

```cpp
// mixes x and y, z untouched
rotationZ:  row0 = {c,-s,0,0}  row1 = {s, c,0,0}  row2 = {0,0,1,0}  row3 = {0,0,0,1}

// mixes x and z, y untouched  (x' = x*c - z*s, z' = x*s + z*c)
rotationY:  row0 = {c,0,-s,0}  row1 = {0,1,0,0}   row2 = {s,0, c,0} row3 = {0,0,0,1}

// mixes y and z, x untouched  (y' = y*c - z*s, z' = y*s + z*c)
rotationX:  row0 = {1,0,0,0}   row1 = {0,c,-s,0}  row2 = {0,s,c,0}  row3 = {0,0,0,1}
```

Bugs hit while writing these (each one compiles fine):
- `int angle` truncates `+= 0.5f` to nothing. Use `float`.
- Computing `angleradians` but passing `angledegrees` to `cos`/`sin`.
- The `c`/`s` entries in the wrong columns (copied the Z pattern for Y), which
  threw away z and divided by zero.
- `rotationX` with `s` and `-s` swapped (still a valid rotation, but turning
  the opposite way to the others).

## Spin in place vs orbit

Rotation matrices always rotate around the origin (0,0,0). If the object's
center is **at** the origin, it spins in place. If not, it swings around the
origin like a ball on a string (and can pass through z ≈ 0 and blow up the
projection).

Fix: move the object's center to the origin, rotate, move back.

```
toorigin = translation(0,0,-6.5)   // cube centre is at z = 6.5
back     = translation(0,0, 6.5)
```

The translate-back does **not** undo the rotation. It only reverses the first
translation. The rotation happened in between and stays. (A book lifted to the
centre of a table, spun a quarter turn and put back is still turned.)

Chain bug: each step must feed the previous result.
`p = toorigin.multiply(p); p = rotate.multiply(p); p = back.multiply(p);`
(not `multiply(original)` each time, which overwrites the earlier steps).

Rotations don't commute. X-then-Y is not the same as Y-then-X.

## Matrix × matrix

`A × B` is the matrix that means "apply B first, then A":
`(A×B)·p = A·(B·p)`.

Entry at row `i`, column `j` of the result = `dot(row i of A, column j of B)`.
Column `j` of the result is A applied to column `j` of B.

Your `mat4` stores rows, so columns are computed on demand (never stored as a
second copy of the data, which would go out of date):

```cpp
Vec4 column0() const { return {row0.x, row1.x, row2.x, row3.x}; }
Vec4 column1() const { return {row0.y, row1.y, row2.y, row3.y}; }
Vec4 column2() const { return {row0.z, row1.z, row2.z, row3.z}; }
Vec4 column3() const { return {row0.w, row1.w, row2.w, row3.w}; }

mat4 multiply(const mat4& other) const {
    Vec4 c0 = other.column0();
    Vec4 c1 = other.column1();
    Vec4 c2 = other.column2();
    Vec4 c3 = other.column3();

    mat4 result;
    result.row0 = { dot(row0,c0), dot(row0,c1), dot(row0,c2), dot(row0,c3) };
    result.row1 = { dot(row1,c0), dot(row1,c1), dot(row1,c2), dot(row1,c3) };
    result.row2 = { dot(row2,c0), dot(row2,c1), dot(row2,c2), dot(row2,c3) };
    result.row3 = { dot(row3,c0), dot(row3,c1), dot(row3,c2), dot(row3,c3) };
    return result;
}
```

Two `multiply` functions with the same name (one takes a `Vec4`, one takes a
`mat4`) is **overloading**: C++ picks by argument type. (Overriding is a
different thing, about virtual functions in inheritance.)

Passing `const mat4&` vs plain `mat4`: both give the same answer. The
reference only saves copying 64 bytes. `const` protects the caller's original
only when it's a reference.

**Order of a chain:** the matrix on the right acts first. For the cube, the
point goes through toorigin, rotateY, rotateX, rotateZ, back, so it's written
with the last step on the left:

```cpp
mat4 combined = back.multiply(rotateZ)
                    .multiply(rotateX)
                    .multiply(rotateY)
                    .multiply(toorigin);
```

Build it once per frame and apply that one matrix to all 8 vertices (instead
of 5 multiplies per vertex). Grouping doesn't change the answer
(`C×(A×B) = (C×A)×B`), but swapping matrices does.

## Perspective as a matrix

A matrix can only make each output as a weighted sum, and a division isn't a
weighted sum. So the matrix can't divide by z. What it can do is **copy z into
the `w` slot**, and your code divides by `w` afterwards.

```cpp
static mat4 perspective(float f) {   // f = 200 here, same as the old scale
    mat4 result;
    result.row0 = {f,0,0,0};
    result.row1 = {0,f,0,0};
    result.row2 = {0,0,1,0};
    result.row3 = {0,0,1,0};   // w' = z
    return result;
}
```

Check: (3,3,5,1) gives (600,600,5,5). Divide by w=5 and you get (120,120), the
same as the old screenpoint.

In this simplified version `z` and `w` hold the same number. Later `z` gets
squeezed into a 0–1 range for depth comparison (Phase 7) and `w` keeps the
plain distance to divide by.

The divide by a small `w` still blows up the same way as the divide by a small
`z` did. The matrix only moved where the divide happens. Real clipping (Phase
10) is the proper fix. For now: skip points whose `w` is under a small cutoff.

## toscreen helper

```cpp
bool toscreen(const mat4& m, Vec3 v, Vec2& out) {
    Vec4 p = {v.x, v.y, v.z, 1};
    p = m.multiply(p);
    if (p.w <= 0.5f) return false;                       // too close / behind
    out = { p.x / p.w + WIDTH / 2.0f, p.y / p.w + HEIGHT / 2.0f };
    return true;
}
```

- Returns `true`/`false` for "visible", and fills in `out` through a reference
  (an **output parameter**: return value says whether it worked, the reference
  carries the result).
- Uses a named `Vec4 p` because `m.multiply({v.x,v.y,v.z,1})` could match
  either overload of `multiply`.

Per vertex: `visible[i] = toscreen(combined, vert[i], sp[i]);`

## View matrix (camera position)

The renderer can only look from the origin down +z, so it can't move the
camera. It moves **the world the opposite way** instead. Moving the camera 2
to the right looks identical to shifting the world 2 to the left.

```cpp
float camX = 0, camY = 0, camZ = 0;
mat4 view = mat4::translation(-camX, -camY, -camZ);

mat4 combined = pers.multiply(view)
                    .multiply(back)
                    .multiply(rotateZ)
                    .multiply(rotateX)
                    .multiply(rotateY)
                    .multiply(toorigin);
```

View goes after the model steps and before the projection.

Axes in this renderer: x increases right, y increases **down**, z increases
**away from you, into the screen**. Increasing `camZ` moves the camera
forward toward the cube (and into it, past the 0.5 cutoff). Negative `camZ`
moves it back.

Camera **position only** so far. Turning the camera comes with the controls
in Phase 10.

## Not solved yet

- No field-of-view setting, no near and far planes (the 0.5 cutoff is a rough
  stand-in).
- Camera can move but not turn.
- Wireframe has no way to show which edges are in front (the cube can flip
  between two readings). Filled faces plus a z-buffer (Phase 7) fix that.
- Spin speed is tied to framerate (60 fps at 1° per frame is 60° per second).
  Multiplying by elapsed time (`sf::Clock`) would fix that.
